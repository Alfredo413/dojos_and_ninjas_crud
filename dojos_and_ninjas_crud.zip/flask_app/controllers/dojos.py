from flask import render_template, request, redirect
from flask_app import app
from flask_app.models.dojo import Dojo

@app.route("/")
def index():
    return redirect('/home')

@app.route('/home')
def homepage():
    dojos=Dojo.getall()
    return render_template('home.html',all_dojos=dojos)

@app.route('/create/dojo', methods=['POST'])
def new_dojo():
    Dojo.save(request.form)
    return redirect('/home')

@app.route('/dojo/<int:id>')
def dojo_show(id):
    data={'id':id }
    return render_template('dojo_show.html',dojo=Dojo.get_ninjas(data))

@app.route('/dojo/delete/<int:id>')
def delete(id):
    data={'id':id}
    Dojo.delete(data)
    return redirect('/')