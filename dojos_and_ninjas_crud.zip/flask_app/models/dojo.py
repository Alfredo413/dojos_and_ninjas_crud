from flask_app.config.mysqlconnection import connectToMySQL
from .ninja import Ninja

class Dojo:
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.cookie_type = data["cookie_type"]
        self.num_boxes = data["boxes"]
        self.ninjas = []

    @classmethod
    def getall(cls):
        dojos=[]
        query='SELECT * FROM dojos;'
        results=connectToMySQL('dojos_and_ninjas_schema').query_db(query)
        for i in results:
            dojos.append(cls(i))
        return dojos

    @classmethod
    def save(cls, data):
        query='INSERT INTO dojos (name) VALUES (%(name)s);'
        return connectToMySQL('dojos_and_ninjas_schema').query_db(query,data)

    @classmethod
    def get_ninjas(cls,data):
        query='SELECT * FROM dojos LEFT JOIN ninjas on dojos.id = ninjas.dojo_id WHERE dojos.id = %(id)s;'
        results=connectToMySQL('dojos_and_ninjas_schema').query_db(query,data)
        dojo=cls(results[0])
        for i in results:
            n = { 'id': i['ninjas.id'], 'first_name': i['first_name'], 'last_name': i['last_name'], 'age': i['age'] }
            dojo.ninjas.append(Ninja(n))
        return dojo

    @classmethod
    def delete(cls,data):
        query='DELETE FROM dojos WHERE id = %(id)s;'
        return connectToMySQL('dojos_and_ninjas_schema').query_db(query,data)